
<head>
  <title>EISA ONLINE BALLOTS</title>

  <meta charset="utf-8">
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width">

  <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,700italic,400,600,700">
  <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Oswald:400,300,700">
  <link rel="stylesheet" href="./css/font-awesome.min.css">
  <link rel="stylesheet" href="./js/libs/css/ui-lightness/jquery-ui-1.9.2.custom.min.css">
  <link rel="stylesheet" href="./css/bootstrap.min.css">

  <!-- Plugin CSS -->
  <link rel="stylesheet" href="./js/plugins/morris/morris.css">
  <link rel="stylesheet" href="./js/plugins/icheck/skins/minimal/blue.css">
  <link rel="stylesheet" href="./js/plugins/select2/select2.css">
  <link rel="stylesheet" href="./js/plugins/fullcalendar/fullcalendar.css">

  <!-- App CSS -->
  <link rel="stylesheet" href="./css/target-admin.css">
  <link rel="stylesheet" href="./css/custom.css">


  <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
  <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
  <![endif]-->
</head>

<body><!-- /.navbar -->

  <div class="mainbar">

  <div class="container">
    <button type="button" class="btn mainbar-toggle" data-toggle="collapse" data-target=".mainbar-collapse">
      <i class="fa fa-bars"></i>
    </button>

    <div class="mainbar-collapse collapse">

      <ul class="nav navbar-nav mainbar-nav">

        <li class="active">
          <a href="home.php">
            <i class="fa fa-dashboard"></i>
            Home
          </a>
          </li>
<li>
          <a href="vote.php">
            <i class="fa fa-book"></i>
            <?php echo mysqli_real_escape_string($localhost, $ballotinfo->getColumnVal("ballot1")); ?>
          </a>
          </li>
          <li>
          <a href="index.php?logout">
            <i class="fa fa-power-off"></i>
            Sign Out
          </a>
          </li>
      </ul>

    </div> <!-- /.navbar-collapse -->   

  </div> <!-- /.container --> 

</div> <!-- /.mainbar -->


<div class="container">

  <div class="content">

    <div class="content-container">

      

      <div>
        <h4 class="heading-inline">Online Ballots</h4>
      </div>

      <br>
<hr>
      <div class=""><?php echo mysqli_real_escape_string($localhost, 'There are 1 ballot paper that needs to be completed. Click on Start Voting to begin voting process'); ?></div>
      <hr>
      <div class="row">
      
        <div class="col-md-3 col-sm-6">
          <div class="thumbnail">
            <div class="thumbnail-views"><img src="img/photos/vote.png" alt="Gallery Image" width="249" height="195" style="width: 100%" /> </div>
            <div class="caption">
            <hr>
              
            </div>
          </div>
          <!-- /.thumbnail -->
        </div>
        <div class="col-md-3 col-sm-6">
          <div class="thumbnail">
            <div class="thumbnail-views"><img src="img/photos/na.png" alt="Gallery Image" width="249" height="195" style="width: 100%" /></div>
            <div class="caption">
              <hr>
              <h3>&nbsp;</h3>
              <hr>
              <p><br>
                <br>
              </p>
              <hr>
              <p><a href="javascript:;" class="btn btn-block btn-default disabled">N/A</a></p>
            </div>
          </div>
          <!-- /.thumbnail -->
        </div>
        <div class="col-md-3 col-sm-6">
          <div class="thumbnail">
            <div class="thumbnail-views"><img src="img/photos/na.png" alt="Gallery Image" width="249" height="195" style="width: 100%" /></div>
            <div class="caption">
              <hr>
              <h3>&nbsp;</h3>
              <hr>
              <p><br>
                <br>
              </p>
              <hr>
              <p><a href="javascript:;" class="btn btn-block btn-default disabled">N/A</a></p>
            </div>
          </div>
          <!-- /.thumbnail -->
        </div>
        <div class="col-md-3 col-sm-6">
          <div class="thumbnail">
            <div class="thumbnail-views"><img src="img/photos/na.png" alt="Gallery Image" width="249" height="195" style="width: 100%" /></div>
            <div class="caption">
              <hr>
              <h3>&nbsp;</h3>
              <hr>
              <p><br>
                <br>
              </p>
              <hr>
              <p><a href="javascript:;" class="btn btn-block btn-default disabled">N/A</a></p>
            </div>
          </div>
          <!-- /.thumbnail -->
        </div>
      </div>
        <!-- /.col --><!-- /.col --><!-- /.col --><!-- /.col -->
        
    </div> <!-- /.row -->

      <br><!-- /.row -->
  </div> <!-- /.content-container -->      
</div> <!-- /.content -->
</div> <!-- /.container --><script src="./js/libs/jquery-1.10.1.min.js"></script>
  <script src="./js/libs/jquery-ui-1.9.2.custom.min.js"></script>
  <script src="./js/libs/bootstrap.min.js"></script>

  <!--[if lt IE 9]>
  <script src="./js/libs/excanvas.compiled.js"></script>
  <![endif]-->  
  <!-- Plugin JS -->
  <script src="./js/plugins/icheck/jquery.icheck.js"></script>
  <script src="./js/plugins/select2/select2.js"></script>
  <script src="./js/libs/raphael-2.1.2.min.js"></script>
  <script src="./js/plugins/morris/morris.min.js"></script>
  <script src="./js/plugins/sparkline/jquery.sparkline.min.js"></script>
  <script src="./js/plugins/nicescroll/jquery.nicescroll.min.js"></script>
  <script src="./js/plugins/fullcalendar/fullcalendar.min.js"></script>
  <!-- App JS -->
  <script src="./js/target-admin.js"></script>  
  <!-- Plugin JS -->
  <script src="./js/demos/dashboard.js"></script>
</body>
</html>
